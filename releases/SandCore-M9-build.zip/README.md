# SandCore M9 精简构建产物

Windows QEMU验证通过，待用户验收。

仅取该版本一套原启动盘、数据盘及启动工具；镜像和原运行工具逐字节不变。
安装 Windows QEMU 后解压运行 run-m9-acceptance.bat（另需Python 3.12）。
数据盘运行时会产生用户修改，请先保留一份解压基线。

源码、文档和第三方许可见 https://github.com/mio-qwq/SandCore 。
