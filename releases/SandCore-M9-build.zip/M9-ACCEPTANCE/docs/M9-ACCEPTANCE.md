完整说明与截图：

https://github.com/mio-qwq/SandCore/blob/main/sandcore/docs/M9-ACCEPTANCE.md
